import { Component } from '@angular/core';
import { User } from  '../user';
@Component({
  selector: 'app-app-component',
  templateUrl: './app-component.component.html',
  styleUrl: './app-component.component.css'
})
export class AppComponentComponent {
user:User[]=[
  {id:1,name:"amy",email:'amy@gmail.com'},
  {id:2,name:"aron",email:'aron@gmail.com'},
  {id:3,name:"steve",email:'steve@gmail.com'}
]
}
